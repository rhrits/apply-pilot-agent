const o="uplyfox-network";export{o as N};
